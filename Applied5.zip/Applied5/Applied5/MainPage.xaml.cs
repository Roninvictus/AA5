﻿using Applied5.Models;
using Applied5.ViewModels;

namespace Applied5;

public partial class MainPage : ContentPage
{

    private MainPageViewModel _viewModel;
    public MainPage(MainPageViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
        _viewModel = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.LoadData();
    }
}