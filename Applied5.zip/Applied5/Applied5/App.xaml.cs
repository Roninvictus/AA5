﻿namespace Applied5;

public partial class App : Application
{
    public static SchoolDatabase SchoolData { get; private set; }
    public App(SchoolDatabase Data)
    {
        InitializeComponent();

        MainPage = new AppShell();

        SchoolData = Data;
    }
}