﻿using Applied5.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;

namespace Applied5.ViewModels;

[QueryProperty(nameof(Student), nameof(Student))]
public partial class StudentPageViewModel : ObservableObject
{
    [ObservableProperty]
    Student student;

    [ObservableProperty]
    bool edit = false;

    [ObservableProperty]
    bool notEdit = false;

    //get list of courses needs for each student
    [ObservableProperty]
    ObservableCollection<Course> courses;

    //course selection
    [ObservableProperty]

    Course selectedCourse;
    [ObservableProperty]

    bool courseEmpty = false;

    public StudentPageViewModel()
    {
        courses = new ObservableCollection<Course>();
        selectedCourse = new Course();
    }

    public async void LoadData()
    {
        if (Student.Name == null)
        {
            NotEdit = true;
        }
        else
        {
            Edit = true;
        }
        Courses = new ObservableCollection<Course>();
        List<Course> courseList = await App.SchoolData.GetAllCourses();
        if (courseList.Count == 0)
        {
            CourseEmpty = true;
        }
        else
        {
            foreach (Course course in courseList)
            {
                Courses.Add(course);
            }
        }
        if (Edit)
        {
            SelectedCourse = courseList.Find(x => x.Id == Student.CourseId);
        }
    }

    [RelayCommand]
    public async Task SaveStudent()
    {
        Student.CourseId = SelectedCourse.Id;
        await App.SchoolData.UpdateStudent(Student);
        await Shell.Current.GoToAsync("..");
    }
    [RelayCommand]
    public async Task AddStudent()
    {
        Student.CourseId = SelectedCourse.Id;
        await App.SchoolData.AddNewStudent(Student);
        await Shell.Current.GoToAsync("..");
    }
}