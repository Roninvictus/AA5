﻿using Applied5.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applied5.ViewModels;

[QueryProperty(nameof(Course), nameof(Course))]
public partial class CoursePageViewModel : ObservableObject
{
    [ObservableProperty]
    Course course;

    [ObservableProperty]
    bool edit = false;
    [ObservableProperty]
    bool notEdit = false;

    public CoursePageViewModel()
    {
        course = new Course();
    }

    //This command is used to set the mode of the page
    public void LoadData()
    {
        if (Course.Name == null)
        {
            NotEdit = true;
        }
        else
        {
            Edit = true;
        }
    }
    //The commands are used to save or add the course to the database
    [RelayCommand]
    public async Task SaveCourse()
    {
        await App.SchoolData.UpdateCourse(Course);
        await Shell.Current.GoToAsync("..");
    }
    [RelayCommand]
    public async Task AddCourse()
    {
        await App.SchoolData.AddNewCourse(Course);
        await Shell.Current.GoToAsync("..");
    }
}
