﻿using Applied5.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Applied5.ViewModels
{
    public partial class MainPageViewModel : ObservableObject
    {
        [ObservableProperty]
        ObservableCollection<Student> students;         //students in database

        [ObservableProperty]
        ObservableCollection<Course> courses;           //courses in database


        [ObservableProperty]
        bool isLoading = true;

        [ObservableProperty]
        bool courseEmpty = false;

        [ObservableProperty]
        bool studentsEmpty = false;

        public MainPageViewModel()
        {
            students = new ObservableCollection<Student>();
            courses = new ObservableCollection<Course>();
        }

        public async void LoadData()
        {
            Students = new ObservableCollection<Student>();//clears lists before fetching data
            Courses = new ObservableCollection<Course>();

            //To get list of students from the database and check if list is populated or not
            List<Student> studentList = await App.SchoolData.GetAllStudents();
            if (studentList.Count == 0)
            {
                StudentsEmpty = true;
            }
            else
            {
                StudentsEmpty = false;
                foreach (Student student in studentList)
                {
                    Students.Add(student);
                }
            }
            List<Course> courseList = await App.SchoolData.GetAllCourses();
            if (courseList.Count == 0)
            {
                CourseEmpty = true;
            }
            else
            {
                CourseEmpty = false;
                foreach (Course course in courseList)
                {
                    Courses.Add(course);
                }
            }
            IsLoading = false;
        }
        [RelayCommand]
        async Task EditStudent(Student student)
        {
            await Shell.Current.GoToAsync($"{nameof(StudentPage)}",
                new Dictionary<string, object>
                {
                    {nameof(Student), student}
                });
        }
        [RelayCommand]
        async Task AddStudent()
        {
            await Shell.Current.GoToAsync($"{nameof(StudentPage)}",
                new Dictionary<string, object>
                {
                    {nameof(Student), new Student()}
                });
        }

        [RelayCommand]
        async Task DeleteStudent(Student student)         //To delete the selected student

        {
            await App.SchoolData.DeleteStudent(student);
            LoadData();
        }
        [RelayCommand]
        async Task EditCourse(Course course)
        {
            await Shell.Current.GoToAsync($"{nameof(CoursePage)}",
                new Dictionary<string, object>
                {
                    {nameof(Course), course}
                });
        }
        [RelayCommand]
        async Task AddCourse()
        {
            await Shell.Current.GoToAsync($"{nameof(CoursePage)}",
                new Dictionary<string, object>
                {
                    {nameof(Course), new Course()}
                });
        }

        [RelayCommand]
        async Task DeleteCourse(Course course)
        {
            await App.SchoolData.DeleteCourse(course);
            LoadData();
        }

    }
}